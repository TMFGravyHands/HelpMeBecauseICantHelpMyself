using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PersonAI : MonoBehaviour {
	
	bool fleeing = false;
	public bool isFleeing
	{
		get { return fleeing; }
		set
		{
			currentSpeed = value ? fleeSpeed : walkSpeed;
			if(value)
				currentFleeTime = 0.0f;
			fleeing = value;
		}
	}
	
	public float walkSpeed = 3;
	public float fleeSpeed = 15;
	
	float currentSpeed;
	
	Vector2 moveDirection = Vector2.zero;
	public Vector2 MoveDirection
	{
		get { return moveDirection; }
	}
	
	public float standardFleeTime = 3;
	float currentFleeTime;
	
	public ThreatTracker threats;
	
	public float goodLookAngle = 30;
	public float goodLookDistance = 25;
	public float maxSketchHelp = .5f;
	
	private int sceneryLayer;
	
	public MoveAnimationScript mas;
	

	// Use this for initialization
	void Start () {
		moveDirection = Random.insideUnitCircle;
		moveDirection.Normalize();
		
		currentSpeed = walkSpeed;
		
		if(Random.Range(0, 100) < 0)
			isFleeing = true;
		else
			isFleeing = false;
		
		sceneryLayer = LayerMask.NameToLayer("Scenery");
	
	}
	
	// Update is called once per frame
	void Update () {
		
		//	Update state machine
		currentFleeTime += Time.deltaTime;
		if(threats.threatDetected)
		{
			if(!isFleeing)
			{
				//	Give description for police sketch
				if(threats.Threat.tag == "Player")
				{
					Vector3 toPlayer = threats.threatPosition - transform.position;
					float angle = Vector3.Angle(toPlayer, moveDirection);
					
					if(angle <= goodLookAngle)
					{
						float sureness = (goodLookAngle - angle) / goodLookAngle;
						float goodSqr = goodLookDistance * goodLookDistance;
						float proximity = Mathf.Clamp((goodSqr - toPlayer.sqrMagnitude) / goodSqr, 0.0f, 1.0f);
						
						PoliceSketch.Instance.SketchCompletionPercentage += proximity * sureness * Random.Range(0.0f, maxSketchHelp);
					}
				}
				isFleeing = true;
				FleeFrom(threats.threatPosition);
			}
		}
		if(fleeing && currentFleeTime > standardFleeTime)
			isFleeing = false;
		
		
		//	Update movement direction & speed
		AvoidScenery();
		mas.moveDir = moveDirection;
		if(currentSpeed > 0)
			mas.isMoving = true;
		else
			mas.isMoving = false;
		rigidbody.velocity = moveDirection * currentSpeed;
	
	}
	
	void FleeFrom(Vector3 threatPos)
	{
		moveDirection = (transform.position - threatPos).normalized;
	}
	
	void AvoidScenery()
	{
		Vector3 secondPoint = transform.position + new Vector3(moveDirection.x, moveDirection.y, 0) * currentSpeed;
		//Debug.DrawLine(transform.position, secondPoint, Color.red);
		Ray stuff = new Ray(transform.position, new Vector3(moveDirection.x, moveDirection.y, 0));
		RaycastHit[] allHits = Physics.RaycastAll(stuff);
		RaycastHit closest = new RaycastHit();
		closest.distance = float.PositiveInfinity;
		
		List<RaycastHit> usefuls = new List<RaycastHit>();
		Vector3 talliedNormal = Vector3.zero;
		foreach(RaycastHit rh in allHits)
		{
			if(rh.collider.gameObject.layer != sceneryLayer)
				continue;
			if(rh.distance > currentSpeed)
				continue;
			if(closest.distance <= rh.distance)
				continue;
			usefuls.Add(rh);
			talliedNormal = talliedNormal * (usefuls.Count / (usefuls.Count + 1)) + rh.normal * (1 / (usefuls.Count + 1));
		}
		if(usefuls.Count > 0)
		{
			Vector3 moveDirNormal = new Vector3(-moveDirection.y, moveDirection.x, 0);
			float normalDot = Vector3.Dot(moveDirNormal, talliedNormal);
			if(normalDot > 0)
			{
				moveDirection += new Vector2(moveDirNormal.x, moveDirNormal.y) * currentSpeed;
			}
			else
			{
				moveDirection -= new Vector2(moveDirNormal.x, moveDirNormal.y) * currentSpeed;
			}
			
			foreach(RaycastHit rh in usefuls)
			{
				Debug.DrawLine(transform.position - Vector3.forward, rh.point - Vector3.forward, Color.green);
				Debug.DrawLine(rh.point - Vector3.forward, rh.point + rh.normal * 1 - Vector3.forward, Color.magenta);
			}
			
			//moveDirection = (secondPoint - transform.position).normalized;
			moveDirection.Normalize();
		}
		//Debug.DrawLine(transform.position, transform.position + new Vector3(moveDirection.x, moveDirection.y, 0) * currentSpeed, Color.green, 3);
		
	}
}
