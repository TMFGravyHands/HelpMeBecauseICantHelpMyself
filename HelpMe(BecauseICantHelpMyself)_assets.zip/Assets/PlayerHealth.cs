using UnityEngine;
using System.Collections;

public class PlayerHealth : MonoBehaviour {
	
	float health = 1;
	public float Health
	{
		get { return health; }
		set
		{
			if(value <= 0)
			{
				Application.LoadLevel("Scene2");
				
				PlayerPrefs.SetString("lose_condition", "killed");
			}
			health = value;
		}
	}

	// Use this for initialization
	void Start () {
		Health = 2;
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	void OnTriggerEnter(Collider other)
	{
		if(LayerMask.LayerToName(other.gameObject.layer) == "CaptureSphere")
		{
			Health = 0;
			PlayerPrefs.SetString("lose_condition", "captured");
		}
	}
}
