using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SingleStab : MonoBehaviour {
	
	List<GameObject> nearbyStabVictims = new List<GameObject>();
	public GameObject disembodiedSound;
	bool continueMurder = true;
	
	public AudioClip missSound;
	

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(nearbyStabVictims.Count > 0 && continueMurder)
		{
			GameObject personToStab = nearbyStabVictims[0];
			if(nearbyStabVictims.Count > 1)
			{
				float leastDist = (personToStab.transform.position - transform.position).sqrMagnitude;
				foreach(GameObject p in nearbyStabVictims)
				{
					float toStabbingDist = (transform.position - p.transform.position).sqrMagnitude;
					if(toStabbingDist < leastDist)
					{
						personToStab = p;
						leastDist = toStabbingDist;
					}
				}
			}
			SendMessageUpwards("MurderHappened", 1);
			KillableObject killable = personToStab.GetComponent<KillableObject>();
			if(killable != null)
				killable.Kill();
			Destroy(personToStab);
			GameObject soundCreated = Instantiate(disembodiedSound, transform.position, Quaternion.identity) as GameObject;
			soundCreated.audio.clip = audio.clip;
			soundCreated.audio.Play();
			continueMurder = false;
		}
		else if(continueMurder)
		{
			//	play swish sound for no murders
			GameObject soundCreated = Instantiate(disembodiedSound, transform.position, Quaternion.identity) as GameObject;
			soundCreated.audio.clip = missSound;
			soundCreated.audio.Play();
			continueMurder = false;
		}
	
	}
	
	void OnTriggerEnter(Collider other)
	{
		if(!continueMurder)
			return;
		if((other.tag == "People" || other.tag == "Police"))
			nearbyStabVictims.Add(other.gameObject);
		
	}
}
