using UnityEngine;
using System.Collections;

public class PersonTestScript : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//rigidbody.velocity = Vector3.zero;
	
	}
	
	void OnTriggerEnter(Collider other)
	{
		if(other.tag == "Player")
			renderer.material.color = Color.green;
	}
	
	void OnTriggerStay(Collider other)
	{
		if(other.tag == "Player")
			renderer.material.color = Color.green;
	}
	
	void OnTriggerExit(Collider other)
	{
		if(other.tag == "Player")
			renderer.material.color = Color.white;
	}
}
