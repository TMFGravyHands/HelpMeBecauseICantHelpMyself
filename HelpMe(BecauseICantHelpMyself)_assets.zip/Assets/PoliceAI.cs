using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PoliceAI : MonoBehaviour {

	bool chasing = false;
	public bool isChasing
	{
		get { return chasing; }
		set
		{
			currentSpeed = value ? chaseSpeed : walkSpeed;
			chasing = value;
		}
	}
	
	public float walkSpeed = 3;
	public float chaseSpeed = 13;
	
	float currentSpeed;
	
	Vector2 moveDirection = Vector2.zero;
	
	public ThreatTracker alertArea;
	
	public float firingRange = 15;
	public float time_before_first_shot = 0.5f;
	public float time_between_rounds = 0.2f;
	public float time_between_rounds_min = 0.15f;
	public float time_between_rounds_max = 0.35f;
	float shootTimer = 0;
	
	public GameObject gunshotEffect;
	
	enum policeState { SHOOTING, CHASING, PATROL, INVESTIGATING };
	policeState currentState = policeState.PATROL;
	
	public MoveAnimationScript mas;
	
	public GameObject captureSphere;
	
	float sceneryLayer;
	
	

	// Use this for initialization
	void Start () {
		moveDirection = Random.insideUnitCircle;
		moveDirection.Normalize();
		
		isChasing = false;
		
		sceneryLayer = LayerMask.NameToLayer("Scenery");
	
	}
	
	// Update is called once per frame
	void Update () {
		
		//	Update state machine
		switch(currentState)
		{
		case policeState.SHOOTING:
			{
				currentSpeed = 0;
				if(alertArea.Threat == null)
				{
					currentState = policeState.CHASING;
					break;
				}
				Vector3 threatDir = alertArea.Threat.transform.position - transform.position;
				RaycastHit[] allHits = Physics.RaycastAll(new Ray(transform.position, threatDir.normalized));
				foreach(RaycastHit rh in allHits)
				{
					if(rh.collider.gameObject.layer == LayerMask.NameToLayer("Scenery"))
					{
						if(threatDir.sqrMagnitude > (rh.distance * rh.distance))
						{
							currentState = policeState.CHASING;
							break;
						}
					}
				}
				if(currentState != policeState.SHOOTING)
					break;	
				if(threatDir.sqrMagnitude > (firingRange * firingRange))
				{
					currentState = policeState.CHASING;
					break;
				}
				
				//	Call out "FREEZE DIRTBAG" here
				shootTimer += Time.deltaTime;
				if(shootTimer > time_before_first_shot)
				{
					Shoot(alertArea.Threat);
					shootTimer -= time_before_first_shot;
					while(shootTimer >= time_between_rounds)
					{
						Shoot(alertArea.Threat);
						shootTimer -= time_between_rounds;
					}
				}
				while(shootTimer >= time_between_rounds)
				{
					Shoot(alertArea.Threat);
					shootTimer -= time_between_rounds;
					time_between_rounds = Random.Range(time_between_rounds_min, time_between_rounds_max);
				}
			}
			break;
		case policeState.CHASING:
			{
				isChasing = true;
				if(!alertArea.threatDetected)
				{
					currentState = policeState.PATROL;
					break;
				}
				Vector3 threatDir = alertArea.threatPosition - transform.position;
				if(Vector3.Angle(threatDir, moveDirection) < 30 && threatDir.sqrMagnitude <= (firingRange * firingRange))
				{
					currentState = policeState.SHOOTING;
					break;
				}
				moveDirection = (alertArea.threatPosition - transform.position).normalized;
			}
			break;
		case policeState.PATROL:
			{
				if(alertArea.threatDetected)
				{
					isChasing = true;
					currentState = policeState.CHASING;
				}
				else if(alertArea.investigatePercent > .5f)
				{
					currentState = policeState.INVESTIGATING;
					break;
				}
				isChasing = false;
			}
			break;
		case policeState.INVESTIGATING:
			{
				if(alertArea.threatDetected)
				{
					captureSphere.SetActive(false);
					currentState = policeState.CHASING;
					break;
				}
				if(alertArea.investigatePercent < .25f)
				{
					captureSphere.SetActive(false);
					currentState = policeState.PATROL;
					break;
				}	
				captureSphere.SetActive(true);
				moveDirection = (alertArea.investigatePosition - transform.position).normalized;
				isChasing = true;
			}
			break;
		default:
			currentState = policeState.PATROL;
			break;
		}
		
		//	Update movement direction & speed
		if(currentSpeed > 0)
			mas.isMoving = true;
		else
			mas.isMoving = false;
		mas.moveDir = moveDirection;
		
		AvoidScenery();
		rigidbody.velocity = moveDirection * currentSpeed;
	
	}
	void Shoot(GameObject target)
	{
		if(target.tag == "Player")
		{
			target.GetComponent<PlayerHealth>().Health -= 1;
		}
		Instantiate(gunshotEffect, transform.position + new Vector3(moveDirection.x, moveDirection.y, 0) * 1, Quaternion.identity);
		
		Debug.DrawLine(alertArea.threatPosition, transform.position);
	}
	
	
	void AvoidScenery()
	{
		Vector3 secondPoint = transform.position + new Vector3(moveDirection.x, moveDirection.y, 0) * currentSpeed;
		//Debug.DrawLine(transform.position, secondPoint, Color.red);
		Ray stuff = new Ray(transform.position, new Vector3(moveDirection.x, moveDirection.y, 0));
		RaycastHit[] allHits = Physics.RaycastAll(stuff);
		RaycastHit closest = new RaycastHit();
		closest.distance = float.PositiveInfinity;
		
		List<RaycastHit> usefuls = new List<RaycastHit>();
		Vector3 talliedNormal = Vector3.zero;
		foreach(RaycastHit rh in allHits)
		{
			if(rh.collider.gameObject.layer != sceneryLayer)
				continue;
			if(rh.distance > currentSpeed)
				continue;
			if(closest.distance <= rh.distance)
				continue;
			usefuls.Add(rh);
			talliedNormal = talliedNormal * (usefuls.Count / (usefuls.Count + 1)) + rh.normal * (1 / (usefuls.Count + 1));
		}
		if(usefuls.Count > 0)
		{
			Vector3 moveDirNormal = new Vector3(-moveDirection.y, moveDirection.x, 0);
			float normalDot = Vector3.Dot(moveDirNormal, talliedNormal);
			if(normalDot > 0)
			{
				moveDirection += new Vector2(moveDirNormal.x, moveDirNormal.y) * currentSpeed;
			}
			else
			{
				moveDirection -= new Vector2(moveDirNormal.x, moveDirNormal.y) * currentSpeed;
			}
			
			foreach(RaycastHit rh in usefuls)
			{
				Debug.DrawLine(transform.position - Vector3.forward, rh.point - Vector3.forward, Color.green);
				Debug.DrawLine(rh.point - Vector3.forward, rh.point + rh.normal * 1 - Vector3.forward, Color.magenta);
			}
			
			//moveDirection = (secondPoint - transform.position).normalized;
			moveDirection.Normalize();
		}
		//Debug.DrawLine(transform.position, transform.position + new Vector3(moveDirection.x, moveDirection.y, 0) * currentSpeed, Color.green, 3);
		
	}
}
