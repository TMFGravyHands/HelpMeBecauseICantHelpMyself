using UnityEngine;
using System.Collections;

public class SelfDestruct : MonoBehaviour {
	
	public float destroyTime = .05f;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		destroyTime -= Time.deltaTime;
		if(destroyTime < 0)
			Destroy(this.gameObject);
	
	}
}
