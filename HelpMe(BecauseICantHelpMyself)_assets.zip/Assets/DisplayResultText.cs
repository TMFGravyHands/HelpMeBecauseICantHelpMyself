using UnityEngine;
using System.Collections;

public class DisplayResultText : MonoBehaviour {
	
	public Material murder_suicide;
	public Material murder_killed;
	public Material murder_captured;
	
	public Material murder_suicide_single;
	public Material murder_killed_single;
	public Material murder_captured_single;
	
	public Material suicide;
	public Material killed;
	public Material captured;

	// Use this for initialization
	void Start () {
		string deathMethod = PlayerPrefs.GetString("lose_condition");
		int numMurders = PlayerPrefs.GetInt("num_murders");
		if(deathMethod == "killed")
		{
			if(numMurders > 1)
				renderer.material = murder_killed;
			else if(numMurders == 1)
				renderer.material = murder_killed_single;
			else
				renderer.material = killed;
		}
		else if(deathMethod == "captured")
		{
			if(numMurders > 1)
				renderer.material = murder_captured;
			else if(numMurders == 1)
				renderer.material = murder_captured_single;
			else
				renderer.material = captured;
		}
		else if(deathMethod == "suicide")
		{
			if(numMurders > 1)
				renderer.material = murder_suicide;
			else if(numMurders == 1)
				renderer.material = murder_suicide_single;
			else
				renderer.material = suicide;
		}
		else
		{
			renderer.enabled = false;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
