using UnityEngine;
using System.Collections;

public class SpaceToRestart : MonoBehaviour {
	
	public float timeout = 3;
	float timer = 0;
	
	bool canLeave = false;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		timer += Time.deltaTime;
		if(!Input.GetButton("Fire1") && timer >= timeout)
		{
			canLeave = true;
		}
		
		if(Input.GetButtonUp("Fire1") && canLeave)
		{
			Application.LoadLevel("build_day_0");
		}
	
	}
}
