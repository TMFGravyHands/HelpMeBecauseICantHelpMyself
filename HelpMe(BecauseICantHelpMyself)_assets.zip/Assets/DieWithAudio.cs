using UnityEngine;
using System.Collections;

public class DieWithAudio : MonoBehaviour {

	// Use this for initialization
	void Start () {
		DontDestroyOnLoad(this.gameObject);
	
	}
	
	// Update is called once per frame
	void Update () {
		if(!audio.isPlaying)
			Destroy (this.gameObject);
	
	}
}
