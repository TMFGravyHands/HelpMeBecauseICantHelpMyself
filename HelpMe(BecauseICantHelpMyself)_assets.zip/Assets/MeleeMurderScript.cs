using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MeleeMurderScript : MonoBehaviour {
	
	List<GameObject> nearbyMurderSubjects = new List<GameObject>();
	
	public GameObject bladeSwipeEffect;
	
	GameObject currentBladeEffect = null;
	
	int numMurdered = 0;
	public int NumMurders
	{
		get { return numMurdered; }
	}
	
	public float hallucinationIntensity = 0;
	
	// Use this for initialization
	void Start () {
		numMurdered = 0;
		PlayerPrefs.SetInt("num_murders", 0);
		
	
	}
	
	// Update is called once per frame
	void Update () {
		
		if(Input.GetButtonDown("Fire1"))
			KillEveryone();
	
	}
	
	void KillEveryone()
	{
		/*
		if(nearbyMurderSubjects.Count > 0)
			BroadcastMessage("OnMurderOccurred", nearbyMurderSubjects.Count);
		foreach(GameObject g in nearbyMurderSubjects)
		{
			if(g != null)
			{
				if(g.tag == "Police")
					Debug.Log("uh oh");
				Destroy(g);
			}
		}*/
		PlayKillEffect(GetComponent<PlayerControls>().lastMoveDirection);
		if(hallucinationIntensity >= 1)
		{
			GetComponent<PlayerHealth>().Health = 0;
			PlayerPrefs.SetString("lose_condition", "suicide");
		}
		nearbyMurderSubjects.Clear();
	}
	
	void OnTriggerEnter(Collider other)
	{
		if((other.tag == "People" || other.tag == "Police"))
			nearbyMurderSubjects.Add(other.gameObject);
		
	}
	
	void OnTriggerExit(Collider other)
	{
		if(other.tag == "People" || other.tag == "Police")
			while(nearbyMurderSubjects.Remove(other.gameObject));
	}
	
	void MurderHappened(int numMurders)
	{
		BroadcastMessage("OnMurderOccurred", numMurders);
		numMurdered += numMurders;
		PlayerPrefs.SetInt("num_murders", numMurdered);
	}
	
	void PlayKillEffect(Vector3 direction)
	{
		if(currentBladeEffect != null)
			return;
		Quaternion newRot = Quaternion.AngleAxis(Vector3.Angle(-Vector3.right, direction), Vector3.forward);
		if(direction.y > 0)
			newRot = Quaternion.AngleAxis(Vector3.Angle(-Vector3.right, direction), -Vector3.forward);
		
		currentBladeEffect = Instantiate(bladeSwipeEffect,
			transform.position + direction * bladeSwipeEffect.transform.localScale.y * 0.5f,
			newRot) as GameObject;
		currentBladeEffect.transform.parent = transform;
	}
}
