using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AnimationScript : MonoBehaviour {
	
	public bool isLooping;
	public List<Material> frames = new List<Material>();
	public bool isConstantTimePerFrame;
	public float constantFrameAnimDur;
	public List<float> frameDurations = new List<float>();
	
	float timer = 0;
	int currentFrame = 0;
	bool isPlaying = false;

	// Use this for initialization
	void Start () {
		Play ();
	
	}
	
	// Update is called once per frame
	void Update () {
		if(isPlaying)
		{
			timer += Time.deltaTime;
			if(isConstantTimePerFrame)
			{
				while(timer >= constantFrameAnimDur)
				{
					++currentFrame;
					timer -= constantFrameAnimDur;
				}
			}
			else
			{
				while(currentFrame < frameDurations.Count && timer >= frameDurations[currentFrame])
				{
					++currentFrame;
					timer -= frameDurations[currentFrame];
				}
			}
			if(currentFrame >= frames.Count)
			{
				if(isLooping)
				{
					currentFrame = 0;
				}
				else
					isPlaying = false;
			}
			if(currentFrame < frames.Count)
			{
				renderer.material = frames[currentFrame];
			}
		}
	
	}
	
	public void Play()
	{
		timer = 0;
		currentFrame = 0;
		isPlaying = true;
		renderer.material = frames[currentFrame];
	}
}
