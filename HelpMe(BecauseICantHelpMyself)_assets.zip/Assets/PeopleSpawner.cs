using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PeopleSpawner : MonoBehaviour {
	
	public float spawnRadius;
	
	public float policePercentage = 1;
	
	public int numPeople = 100;
	public GameObject personPrefab = null;
	public GameObject policePrefab = null;
	
	List<GameObject> spawnedPeople = new List<GameObject>();
	
	public Vector2 cameraViewSize;
	public Vector2 despawnSize;

	// Use this for initialization
	void Start () {
		
		while(spawnedPeople.Count < numPeople)
		{
			spawnedPeople.Add(CreatePerson(false, Random.Range(0.0f, 100.0f) < policePercentage));
		}
	
	}
	
	// Update is called once per frame
	void Update () {
		for(int i = 0; i < spawnedPeople.Count; ++i)
		{
			GameObject person = spawnedPeople[i];
			if(person == null)
			{
				spawnedPeople.RemoveAt(i);
				spawnedPeople.Add(CreatePerson(true, Random.Range(0.0f, 100.0f) < policePercentage));
				--i;
				continue;
			}
			
			Vector3 fromCam = person.transform.position - transform.position;
			if(Mathf.Abs(fromCam.x) > despawnSize.x || Mathf.Abs(fromCam.y) > despawnSize.y)
			{
				spawnedPeople.RemoveAt(i);
				Destroy(person);
				spawnedPeople.Add(CreatePerson(true, Random.Range(0.0f, 100.0f) < policePercentage));
				--i;
			}
		}
	
	}
	
	GameObject CreatePerson(bool outsideInnerBox, bool isPolice)
	{
		int timesFailed = 0;
		GameObject created = null;
		while(created == null)
		{
			Vector3 personPos = transform.position;
		
		//	Find spawn location
			Vector2 offset = Vector2.zero;
			do {
				offset = new Vector2(Random.Range(-despawnSize.x, despawnSize.x), Random.Range(-despawnSize.y, despawnSize.y));
			} while(outsideInnerBox && Mathf.Abs(offset.x) < cameraViewSize.x && Mathf.Abs(offset.y) < cameraViewSize.y);
		
			personPos += new Vector3(offset.x, offset.y, 0);
			personPos.z = 0;
			
			
			if(timesFailed > 50)
			{
				//created = (Instantiate(personPrefab, personPos, Quaternion.identity) as GameObject);
				//break;
			}
			RaycastHit[] allHits = Physics.SphereCastAll(new Ray(personPos - Vector3.forward * 6, Vector3.forward), 2);
			bool create = true;
			Debug.DrawLine(personPos - Vector3.forward * 6, personPos - Vector3.forward * 2 + Vector3.forward * 15, Color.magenta, 5);
			foreach(RaycastHit rh in allHits)
			{
				if(rh.collider.gameObject.layer == LayerMask.NameToLayer("Scenery"))
				{
					create = false;
					break;
				}
			}
			if(create)
			{
				if(isPolice)
					created = (Instantiate(policePrefab, personPos, Quaternion.identity) as GameObject);
				else
					created = (Instantiate(personPrefab, personPos, Quaternion.identity) as GameObject);
			}
			++timesFailed;
		}
		
		return created;
	}
}
