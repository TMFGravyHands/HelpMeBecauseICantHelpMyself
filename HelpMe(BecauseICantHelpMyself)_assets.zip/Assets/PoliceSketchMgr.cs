using UnityEngine;
using System.Collections;

public class PoliceSketchMgr : MonoBehaviour {
	
	float prevFramePercentage = 0;
	PoliceSketch sketch = PoliceSketch.Instance;

	// Use this for initialization
	void Start () {
		sketch.SketchCompletionPercentage = prevFramePercentage = 0;
	
	}
	
	// Update is called once per frame
	void Update () {
		if(sketch.SketchCompletionPercentage != prevFramePercentage)
		{
			prevFramePercentage = sketch.SketchCompletionPercentage;
			if(prevFramePercentage > 0)
				renderer.enabled = false;
			else
				renderer.enabled = false;
		}
	
	}
}

public class PoliceSketch
{
	private static readonly PoliceSketch _instance = new PoliceSketch();
	public static PoliceSketch Instance
	{
		get { return _instance; }
	}
	
	float sketchPercentage;
	public float SketchCompletionPercentage
	{
		get { return sketchPercentage; }
		set
		{
			sketchPercentage = Mathf.Clamp(value, 0.0f, 1.0f);
			Debug.Log("Sketch percent:  " + sketchPercentage.ToString());
		}
	}
}
