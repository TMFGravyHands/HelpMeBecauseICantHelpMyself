using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DisplayResultKillCount : MonoBehaviour {
	
	public List<GameObject> numbers = new List<GameObject>();

	// Use this for initialization
	void Start () {
		int numMurders = PlayerPrefs.GetInt("num_murders");
		if(numMurders < 2)
			return;
		
		float leftPos = transform.position.x;
		string murderNumString = numMurders.ToString();
		for(int i = 0; i < murderNumString.Length; ++i)
		{
			GameObject creating = numbers[murderNumString[i] - '0'];
			Instantiate(creating, new Vector3(leftPos + creating.transform.localScale.x * 10, transform.position.y, -2), creating.transform.localRotation);
			leftPos += (creating.transform.localScale.x + 1) * 10;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
