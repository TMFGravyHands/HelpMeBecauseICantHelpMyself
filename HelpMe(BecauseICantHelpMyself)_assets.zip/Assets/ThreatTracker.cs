using UnityEngine;
using System.Collections;

public class ThreatTracker : MonoBehaviour {
	
	public bool threatDetected;
	public Vector3 threatPosition;
	GameObject threatObject;
	public GameObject Threat
	{
		get { return threatObject; }
	}
	
	public float investigatePercent;
	public Vector3 investigatePosition;
	Vector3 currInvestigatePositionThisFrame = Vector3.zero;
	float currInvestigatePercentThisFrame = 0;
	int currInvestigatesThisFrame = 0;
	GameObject investigateObject;
	
	bool subjectSeenThisFrame = false;
	float subjectSeenTimer = 0;
	public float timeForPositiveID = 1;
	
	private int sceneryLayer;
	
	// Use this for initialization
	void Start () {
		sceneryLayer = LayerMask.NameToLayer("Scenery");
	
	}
	
	// Update is called once per frame
	void Update () {
		if(investigateObject == null)
		{
			investigatePosition = currInvestigatePositionThisFrame;
			investigatePercent = currInvestigatePercentThisFrame;
		}
		currInvestigatePositionThisFrame = Vector3.zero;
		currInvestigatesThisFrame = 0;
		currInvestigatePercentThisFrame = 0;
		
		if(investigateObject == null)
		{
			subjectSeenTimer = 0;
		}
		else
		{
			subjectSeenTimer += Time.deltaTime;
			Debug.LogError(subjectSeenTimer);
			if(PoliceSketch.Instance.SketchCompletionPercentage > 0)
			{
				investigatePercent = (subjectSeenTimer / timeForPositiveID) * PoliceSketch.Instance.SketchCompletionPercentage;
				investigatePosition = investigateObject.transform.position;
			}
		}
		subjectSeenThisFrame = false;
	
	}
	
	void OnTriggerEnter(Collider col)
	{
		Ray stuff = new Ray(transform.position, (col.transform.position - transform.position).normalized);
		float distanceSqr = (col.transform.position - transform.position).sqrMagnitude;
		RaycastHit[] allHits = Physics.RaycastAll(stuff);
		foreach(RaycastHit rh in allHits)
		{
			float rhDistSqr = rh.distance * rh.distance;
			if(rhDistSqr > distanceSqr)
			{
				continue;
			}
			if(rh.collider.gameObject.layer == sceneryLayer)
			{
				//Debug.DrawLine(transform.position, rh.point, Color.blue, 3);
				return;
			}
		}
		if(col.tag == "BladeSwipe")
		{
			threatDetected = true;
			threatObject = col.transform.parent.gameObject;
			threatPosition = col.transform.position;
		}
		if(col.tag == "People")
		{
			FleeingPersonSeen(col);
		}
		if(col.tag == "Player")
		{
			if(PoliceSketch.Instance.SketchCompletionPercentage > 0)
			{
				Debug.LogError(col.tag);
				subjectSeenThisFrame = true;
				investigateObject = col.gameObject;
			}
		}
	}
	
	void FleeingPersonSeen(Collider col)
	{
		PersonAI pAI = col.gameObject.GetComponent<PersonAI>();
		if(!pAI.isFleeing)
			return;
		currInvestigatePercentThisFrame += 0.5f;
		Vector3 toPerson = col.transform.position - transform.position;
		
		Vector3 aiMoveDir = new Vector3(pAI.MoveDirection.x, pAI.MoveDirection.y, 0);
		Vector3 newInvestigateDir = -(aiMoveDir * pAI.fleeSpeed);
		++currInvestigatesThisFrame;
		currInvestigatePositionThisFrame =
			(currInvestigatePositionThisFrame * ((currInvestigatesThisFrame - 1) / currInvestigatesThisFrame))
			+ newInvestigateDir * (1.0f / currInvestigatesThisFrame);
	}
	
	void OnTriggerStay(Collider col)
	{
		Ray stuff = new Ray(transform.position, (col.transform.position - transform.position).normalized);
		float distanceSqr = (col.transform.position - transform.position).sqrMagnitude;
		RaycastHit[] allHits = Physics.RaycastAll(stuff);
		foreach(RaycastHit rh in allHits)
		{
			float rhDistSqr = rh.distance * rh.distance;
			if(rhDistSqr > distanceSqr)
			{
				continue;
			}
			if(rh.collider.gameObject.layer == sceneryLayer)
			{
				//Debug.DrawLine(transform.position, rh.point, Color.blue, 3);
				return;
			}
		}
		if(col.gameObject == threatObject)
		{
			threatPosition = col.transform.position;
		}
		if(col.gameObject == investigateObject)
		{
			
		}
		if(col.tag == "Player")
		{
			if(PoliceSketch.Instance.SketchCompletionPercentage >= 1)
			{
				threatDetected = true;
				threatObject = col.gameObject;
				threatPosition = col.transform.position;
			}
			else if(PoliceSketch.Instance.SketchCompletionPercentage > 0)
			{
				subjectSeenThisFrame = true;
				investigateObject = col.gameObject;
			}
		}
		if(col.tag == "People")
		{
			//FleeingPersonSeen(col);
		}
	}
	
	void OnTriggerExit(Collider col)
	{
		if(col.gameObject == investigateObject)
		{
			investigateObject = null;
			investigatePercent = 0.0f;
		}
		
		if(col.gameObject == threatObject)
		{
			threatObject = null;
		}
	}
	
	public void ClearThreat()
	{
		threatObject = null;
		threatDetected = false;
	}
}
