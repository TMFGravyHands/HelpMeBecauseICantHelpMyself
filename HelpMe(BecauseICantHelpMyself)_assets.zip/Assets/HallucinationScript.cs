using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HallucinationScript : MonoBehaviour {
	
	public GameObject hallucinationEffect;
	
	float timer = 0;
	public float hallucinationTime = 1;
	public float severeHallucinationTime = 10;
	
	public float currentHallucinationSeverity = 0;
	
	public float effectSwapTime = .05f;
	float effectTimer = 0;
	public List<Material> hallucinationMaterials = new List<Material>();
	int currEffectDisplayed = 0;
	public float maxDowntimeBetweenEffects = 1.5f;
	
	public AudioSource creepy1;
	public float creepy1_startTime;
	public AudioSource creepy2;
	public float creepy2_startTime;
	public AudioSource creepy3;
	public float creepy3_startTime;
	
	public MeleeMurderScript SuicideThing;

	// Use this for initialization
	void Start () {
		hallucinationEffect.SetActive(false);
		audio.volume = 0;
	
	}
	
	// Update is called once per frame
	void Update () {
		
		timer += Time.deltaTime;
		
		if(timer >= hallucinationTime)
		{
			float untilSevere = severeHallucinationTime - timer;
			float severeGap = severeHallucinationTime - hallucinationTime;
			currentHallucinationSeverity = 1.0f - Mathf.Clamp(untilSevere / severeGap, 0.0f, 1.0f);
			if(!audio.isPlaying)
				audio.Play();
			audio.volume = currentHallucinationSeverity;
			hallucinationEffect.SetActive(true);
			if(timer >= creepy1_startTime && !creepy1.isPlaying)
				creepy1.Play();
			if(timer >= creepy2_startTime && !creepy2.isPlaying)
				creepy2.Play();
			if(timer >= creepy3_startTime && !creepy3.isPlaying)
				creepy3.Play();
			
			effectTimer += Time.deltaTime;
			if(currEffectDisplayed >= hallucinationMaterials.Count)
			{
				hallucinationEffect.SetActive(false);
				if(effectTimer >= ((1.0f - currentHallucinationSeverity) * maxDowntimeBetweenEffects))
				{
					currEffectDisplayed = 0;
					hallucinationEffect.renderer.material = hallucinationMaterials[currEffectDisplayed];
					hallucinationEffect.SetActive(true);
					effectTimer = 0;
				}
			}
			else
			{
				while(effectTimer >= effectSwapTime)
				{
					effectTimer -= effectSwapTime;
					++currEffectDisplayed;
					if(currEffectDisplayed < hallucinationMaterials.Count)
					{
						hallucinationEffect.renderer.material = hallucinationMaterials[currEffectDisplayed];
					}
					else
					{
						hallucinationEffect.SetActive(false);
					}
				}
			}
		}
		else
		{
			currentHallucinationSeverity = 0;
			if(audio.volume > 0)
			{
				audio.volume -= Time.deltaTime * 2;
			}
			creepy1.Stop();
			creepy2.Stop();
			creepy3.Stop();
			effectTimer = 0;
		}
		SuicideThing.hallucinationIntensity = currentHallucinationSeverity;
	
	}
	
	public void OnMurderOccurred(int numMurders)
	{
		timer = 0.0f;
		hallucinationEffect.SetActive(false);
	}
}
