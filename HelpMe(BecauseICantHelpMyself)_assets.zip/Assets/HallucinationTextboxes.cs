using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HallucinationTextboxes : MonoBehaviour {
	
	public List<GameObject> possibles;
	
	public float percentHaveOne = 10;
	
	GameObject mine = null;
	
	bool show = false;
	public bool Show
	{
		get { return show; }
	}
	
	float myThreshold = 0;
	
	public HallucinationScript hs;

	// Use this for initialization
	void Start () {
		
		hs = GameObject.Find("Main Camera").GetComponent<HallucinationScript>();
		
		if(Random.Range(0.0f, 100.0f) < percentHaveOne)
		{
			myThreshold = Random.Range(0.0f, 1.0f);
			int chosen = Random.Range(0, 3);
			mine = Instantiate(possibles[chosen], transform.position,
				transform.localRotation) as GameObject;
			mine.transform.localScale = new Vector3(possibles[chosen].transform.localScale.x,
				possibles[chosen].transform.localScale.y,
				possibles[chosen].transform.localScale.z);
			mine.transform.parent = transform;
			mine.renderer.enabled = false;
			show = false;
		}
	
	}
	
	// Update is called once per frame
	void Update () {
		
		if(mine != null && hs.currentHallucinationSeverity >= myThreshold)
		{
			mine.renderer.enabled = true;
			show = true;
		}
		else if(mine != null)
		{
			mine.renderer.enabled = false;
			show = false;
		}
	
	}
}

















