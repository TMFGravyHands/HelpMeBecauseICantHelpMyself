using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class MoveAnimationScript : MonoBehaviour {
	
	public List<Material> left;
	public List<Material> right;
	public List<Material> up;
	public List<Material> down;
	
	int currFrame = 0;
	
	public float timePerWalkFrame = .2f;
	float timer = 0;
	Vector3 prevMoveDir = Vector3.zero;
	public Vector3 moveDir = Vector3.zero;
	public bool isMoving = true;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		List<Material> current = right;
		float smallestAngle = Vector3.Angle(moveDir, Vector3.right);
		
		float tempAngle = Vector3.Angle(moveDir, Vector3.up);
		if(tempAngle < smallestAngle)
		{
			smallestAngle = tempAngle;
			current = up;
		}
		
		tempAngle = Vector3.Angle(moveDir, -Vector3.up);
		if(tempAngle < smallestAngle)
		{
			smallestAngle = tempAngle;
			current = down;
		}
		
		tempAngle = Vector3.Angle(moveDir, -Vector3.right);
		if(tempAngle < smallestAngle)
		{
			smallestAngle = tempAngle;
			current = left;
		}
		
		timer += Time.deltaTime;
		while(timer >= timePerWalkFrame)
		{
			timer -= timePerWalkFrame;
			++currFrame;
		}
		if(currFrame >= current.Count)
		{
			currFrame = 0;
		}
		
		
		if(!isMoving)
		{
			renderer.material = current[0];
			currFrame = 0;
			timer = 0;
		}
		else
		{
			renderer.material = current[currFrame];
		}
	
	}
}
