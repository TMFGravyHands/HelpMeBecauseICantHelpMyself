using UnityEngine;
using System.Collections;

public class PlayerControls : MonoBehaviour {
	
	public float speed = 5;
	
	public Vector3 lastMoveDirection = -Vector3.up;
	
	public MoveAnimationScript mas;
	
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		Vector3 frameMoveDir = Vector3.zero;
		rigidbody.WakeUp();
		
		frameMoveDir = new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"), 0);
		if(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
		{
		//	frameMoveDir -= Vector3.right;
		}
		if(Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
		{
		//	frameMoveDir += Vector3.right;
		}
		if(Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
		{
		//	frameMoveDir += Vector3.up;
		}
		if(Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
		{
		//	frameMoveDir -= Vector3.up;
		}
		frameMoveDir.Normalize();
		if(frameMoveDir != Vector3.zero)
		{
			lastMoveDirection = frameMoveDir;
			mas.isMoving = true;
		}
		else
		{
			mas.isMoving = false;
		}
		mas.moveDir = lastMoveDirection;
		GetComponent<CharacterController>().Move(frameMoveDir * speed * Time.deltaTime);
	
	}
}
