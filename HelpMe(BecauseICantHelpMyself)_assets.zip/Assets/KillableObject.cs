using UnityEngine;
using System.Collections;

public class KillableObject : MonoBehaviour {
	
	public GameObject toReplaceWith;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	
	public void Kill()
	{
		if(toReplaceWith != null)
		{
			GameObject create = Instantiate(toReplaceWith) as GameObject;
			create.transform.position = transform.position - Vector3.forward * 0.2f;
			create.transform.parent = transform.parent;
		}
	}
}
